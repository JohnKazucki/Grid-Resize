import bpy

addon_name = __name__.partition('.')[0]
